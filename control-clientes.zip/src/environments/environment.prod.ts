export const environment = {
  production: true,
  firestore:{
    apiKey: "AIzaSyAPzMJ5dVEI8GUETxXGXSdMS10CRgBX0Vc",
    authDomain: "control-clientes-b71cb.firebaseapp.com",
    databaseURL: "https://control-clientes-b71cb.firebaseio.com",
    projectId: "control-clientes-b71cb",
    storageBucket: "control-clientes-b71cb.appspot.com",
    messagingSenderId: "777714836914",
    appId: "1:777714836914:web:aa03c3233e330074"
  }
};
